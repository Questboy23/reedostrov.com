#!/bin/bash
# Installs Voice Computer Agent from this folder: Python deps, whisper.cpp, and the menu bar app at login.
# Run from the unzipped folder: bash install.sh
set -euo pipefail
cd "$(dirname "$0")"
DIR="$(pwd)"

[ "$(uname)" = "Darwin" ] || { echo "macOS only."; exit 1; }
command -v uv >/dev/null || { echo "Install uv first: brew install uv  (or see docs.astral.sh/uv)"; exit 1; }
command -v cmake >/dev/null || { echo "Install cmake first: brew install cmake"; exit 1; }

uv sync --extra mac  # pyobjc: menu bar, clicks, screen capture
bash scripts/install_whisper.sh
command -v ollama >/dev/null && ollama pull qwen3.5:9b || echo "Free mode: install Ollama from ollama.com, then run: ollama pull qwen3.5:9b"
command -v agent-desktop >/dev/null || echo "Optional: brew install agent-desktop (faster clicks that do not move your mouse)"
[ -x "$HOME/.local/bin/claude" ] || echo "Optional, for Claude help: install Claude Code (claude.com/code) and run: claude  (sign in once)"

bash scripts/make_app.sh  # menu bar icons and permissions need a real app bundle
PLIST="$HOME/Library/LaunchAgents/com.voice-computer-agent.menubar.plist"
mkdir -p "$HOME/Library/LaunchAgents"
cat > "$PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>Label</key><string>com.voice-computer-agent.menubar</string>
<key>ProgramArguments</key><array><string>/usr/bin/open</string><string>-W</string><string>-a</string><string>$HOME/Applications/Voice Computer Agent.app</string></array>
<key>RunAtLoad</key><true/>
<key>KeepAlive</key><dict><key>SuccessfulExit</key><false/></dict>
</dict></plist>
EOF
launchctl bootout "gui/$(id -u)" "$PLIST" 2>/dev/null || true
launchctl bootstrap "gui/$(id -u)" "$PLIST"

PY="$HOME/Applications/Voice Computer Agent.app"
echo
echo "Installed. The menu bar shows a grey ring."
echo "Last step: System Settings > Privacy & Security. Under Accessibility AND under"
echo "Screen & System Audio Recording, click + and pick this app. Also allow it under Menu Bar:"
echo "  $PY"
echo "Then click the menu bar ring > Check setup."
open "x-apple.systempreferences:com.apple.preference.security?Privacy_Accessibility"
