#!/bin/bash
# Installs whisper.cpp from the official ggml-org release tarball and the base.en model.
# Both downloads are checked against pinned sha256 values before anything runs.
# No script is piped to a shell.
set -euo pipefail
VER=1.9.5
SRC_SHA=ff1a9053feb509ff9d7729703355541ae9690073a6b1c40eb692c962e0dc1720
MODEL_SHA=a03779c86df3323075f5e796cb2ce5029f00ec8869eee3fdfb897afe36c6d002
DEST="${VCA_WHISPER_DIR:-$HOME/.voice-computer-agent/whisper}"
mkdir -p "$DEST" && cd "$DEST"

check() { echo "$2  $1" | shasum -a 256 -c - >/dev/null || { echo "CHECKSUM FAIL: $1"; rm -f "$1"; exit 1; }; }

if [ ! -x "$DEST/bin/whisper-cli" ]; then
  curl -fsSL -o src.tar.gz "https://github.com/ggml-org/whisper.cpp/archive/refs/tags/v$VER.tar.gz"
  check src.tar.gz "$SRC_SHA"
  rm -rf src && mkdir src && tar -xzf src.tar.gz -C src --strip-components 1
  cmake -S src -B build -DCMAKE_BUILD_TYPE=Release -DWHISPER_BUILD_TESTS=OFF -DBUILD_SHARED_LIBS=OFF >/dev/null
  cmake --build build -j --config Release --target whisper-cli >/dev/null
  mkdir -p bin && cp build/bin/whisper-cli bin/
  (cd bin && shasum -a 256 whisper-cli > whisper-cli.sha256)
fi
[ -f bin/whisper-cli.sha256 ] || { echo "no recorded binary hash; delete $DEST/bin and rerun"; exit 1; }
(cd bin && shasum -a 256 -c whisper-cli.sha256 >/dev/null) || { echo "BINARY HASH FAIL: whisper-cli changed"; exit 1; }
if [ ! -f ggml-base.en.bin ]; then
  curl -fsSL -o ggml-base.en.bin "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-base.en.bin"
fi
check ggml-base.en.bin "$MODEL_SHA"
echo "OK $DEST/bin/whisper-cli"
