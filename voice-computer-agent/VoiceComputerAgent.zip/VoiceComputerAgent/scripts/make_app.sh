#!/bin/bash
# Builds ~/Applications/Voice Computer Agent.app: a real app bundle around the menu bar.
# macOS shows menu bar icons and lists privacy permissions per app, so a bundle is needed for both.
set -euo pipefail
DIR="$(cd "$(dirname "$0")/.." && pwd)"
APP="$HOME/Applications/Voice Computer Agent.app"
rm -rf "$APP" && mkdir -p "$APP/Contents/MacOS"
cat > "$APP/Contents/Info.plist" <<PL
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleIdentifier</key><string>com.voice-computer-agent.app</string>
<key>CFBundleName</key><string>Voice Computer Agent</string>
<key>CFBundleExecutable</key><string>vca</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>0.1</string>
<key>LSUIElement</key><true/>
<key>NSMicrophoneUsageDescription</key><string>Records your spoken goal between the two key presses.</string>
</dict></plist>
PL
cat > "$APP/Contents/MacOS/vca" <<SH
#!/bin/zsh
cd '$DIR' && exec '$DIR/.venv/bin/python' -m voice_computer_agent.runner menubar
SH
chmod +x "$APP/Contents/MacOS/vca"
codesign --force --sign - "$APP" 2>/dev/null || true
echo "$APP"
