"""Menu bar item (next to Wi-Fi and battery). The user's control panel; the agent never writes these settings.

Icon: grey ring = off, green dot = working on screen, green half dot = working in background, yellow = Claude (cloud) planning or background. Flashes while working.
Menu: Talk now, Type a goal, Check setup, Quick guide, Guide/Auto, Free/Hybrid/Claude, Stop (same as Escape), held actions, Quit.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from pathlib import Path

from .kill_switch import paths, trigger_stop

GUIDE_PDF = Path(__file__).resolve().parents[2] / "docs" / "quick_guide.pdf"
SETTINGS_DEFAULT = {"mode": "guide", "provider": "hybrid"}


def settings_path(state_dir=None) -> Path:
    return paths(state_dir)["stop"].parent / "menu_settings.json"


def load_settings(state_dir=None) -> dict:
    try:
        d = json.loads(settings_path(state_dir).read_text())
    except (OSError, ValueError):
        return dict(SETTINGS_DEFAULT)
    out = dict(SETTINGS_DEFAULT)
    if d.get("mode") in ("guide", "auto"):
        out["mode"] = d["mode"]
    if d.get("provider") in ("free", "hybrid", "claude"):
        out["provider"] = d["provider"]
    return out


def save_settings(s: dict, state_dir=None) -> None:
    p = settings_path(state_dir)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({"mode": s["mode"], "provider": s["provider"]}))


def agent_state(state_dir=None) -> tuple[str, str]:
    """('off'|'on'|'background'|'cloud', label) from the files the runner and glow already write."""
    p = paths(state_dir)
    try:
        pgid = int(p["agent_pgid"].read_text().strip())
        os.killpg(pgid, 0)
    except (OSError, ValueError):
        return "off", ""
    try:
        g = json.loads((p["stop"].parent / "glow_state.json").read_text())
        if g.get("state") == "background":
            return "background", str(g.get("label", ""))[:40]
        if g.get("cloud"):
            return "cloud", str(g.get("goal", ""))[:40]
    except (OSError, ValueError):
        pass
    return "on", ""


def recording(state_dir=None) -> bool:
    """push_to_talk_goal writes ptt.wav while the microphone is on."""
    return (paths(state_dir)["stop"].parent / "ptt.wav").exists()


def icon_color(state: str, AppKit):
    """Green = working on this Mac's screen. Yellow = partly: Claude in the cloud plans, or working in background."""
    if state == "off":
        return AppKit.NSColor.secondaryLabelColor()
    return AppKit.NSColor.systemGreenColor() if state == "on" else AppKit.NSColor.systemYellowColor()


def title_for(state: str) -> str:
    return {"off": "○", "on": "●", "background": "◐", "cloud": "●"}[state]


def status_line(state: str, label: str) -> str:
    return {"off": "Agent is off", "on": "Agent is working on screen",
            "background": f"Agent is working in background: {label}".rstrip(": "),
            "cloud": f"Claude (cloud) is planning: {label}".rstrip(": ")}[state]


def run_args(settings: dict, source: list[str] | None = None) -> list[str]:
    return [sys.executable, "-m", "voice_computer_agent.runner", "run", *(source or ["--box"]),
            "--mode", settings["mode"], "--provider", settings["provider"]]


def inbox_dirs(state_dir=None) -> tuple[Path, Path]:
    base = paths(state_dir)["stop"].parent
    inbox, outbox = base / "inbox", base / "outbox"
    for d in (inbox, outbox):
        d.mkdir(parents=True, exist_ok=True)
        os.chmod(d, 0o700)  # only this user's processes may queue goals or read results
    return inbox, outbox


def send_goal(goal: str, state_dir=None) -> str:
    """Queue one goal; returns the job id. The menu bar runs queued goals one at a time."""
    goal = " ".join(goal.split())[:500]
    if not goal:
        raise ValueError("empty goal")
    inbox, _ = inbox_dirs(state_dir)
    job = f"{time.time_ns()}"
    tmp = inbox / f".{job}.tmp"
    tmp.write_text(goal)
    tmp.rename(inbox / f"{job}.txt")  # atomic, so the menu bar never reads half a goal
    return job


def next_goal(state_dir=None) -> tuple[str, str] | None:
    """Pop the oldest queued goal as (job id, goal)."""
    inbox, _ = inbox_dirs(state_dir)
    for f in sorted(inbox.glob("*.txt")):
        goal = f.read_text().strip()
        f.unlink()
        if goal:
            return f.stem, goal
    return None


def wait_result(job: str, timeout: float, state_dir=None) -> str | None:
    _, outbox = inbox_dirs(state_dir)
    out, end = outbox / f"{job}.txt", time.time() + timeout
    while time.time() < end:
        if out.exists() and out.read_text().endswith("\n[end]\n"):
            return out.read_text().removesuffix("\n[end]\n").strip()
        time.sleep(1)
    return None


def controller_class(state_dir=None):
    """Builds the menu controller class. Creating the class needs no window server, so tests can check it."""
    import AppKit
    import objc
    from Foundation import NSObject, NSTimer

    class Controller(NSObject):
        @objc.python_method
        def setup(self):
            self.s = load_settings(state_dir)
            bar = AppKit.NSStatusBar.systemStatusBar()
            self.item = bar.statusItemWithLength_(AppKit.NSVariableStatusItemLength)
            self.menu = AppKit.NSMenu.alloc().init()
            self.status = self._add("Agent is off", None, "")
            self.status.setEnabled_(False)
            self.menu.addItem_(AppKit.NSMenuItem.separatorItem())
            self._add("Talk now (Right Option or F5)", "talkNow:", "t")
            self._add("Type a goal…", "newGoal:", "g")
            self.stop = self._add("Stop (Escape)", "stopAgent:", "")
            self.menu.addItem_(AppKit.NSMenuItem.separatorItem())
            self.guide = self._add("Guide mode (points, you click)", "setGuide:", "1")
            self.auto = self._add("Auto mode (clicks while you watch)", "setAuto:", "2")
            self.menu.addItem_(AppKit.NSMenuItem.separatorItem())
            self.free = self._add("Free mode (on this Mac)", "setFree:", "3")
            self.hybrid = self._add("Hybrid (free, asks Claude when stuck)", "setHybrid:", "4")
            self.claude = self._add("Claude mode (every step)", "setClaude:", "5")
            self.menu.addItem_(AppKit.NSMenuItem.separatorItem())
            self._add("Show held actions", "showHeld:", "h")
            self._add("Check setup", "checkSetup:", "d")
            self._add("Quick guide", "openGuide:", "?")
            self._add("Quit menu", "quit:", "q")
            self.item.setMenu_(self.menu)
            self.start_hotkey()
            self.refresh_(None)
            NSTimer.scheduledTimerWithTimeInterval_target_selector_userInfo_repeats_(1.0, self, b"refresh:", None, True)

        @objc.python_method
        def _add(self, title, action, key):
            it = AppKit.NSMenuItem.alloc().initWithTitle_action_keyEquivalent_(title, action, key)
            it.setTarget_(self)
            self.menu.addItem_(it)
            return it

        def refresh_(self, _):
            self.run_inbox()
            st, label = agent_state(state_dir)
            color = icon_color(st, AppKit)
            self.blink = not getattr(self, "blink", False)
            if st != "off" and self.blink:  # flashes once a second while working
                color = color.colorWithAlphaComponent_(0.35)
            self.item.button().setAttributedTitle_(AppKit.NSAttributedString.alloc().initWithString_attributes_(
                title_for(st), {AppKit.NSForegroundColorAttributeName: color}))
            self.status.setTitle_(status_line(st, label))
            self.stop.setEnabled_(st != "off")
            self.guide.setState_(self.s["mode"] == "guide")
            self.auto.setState_(self.s["mode"] == "auto")
            self.free.setState_(self.s["provider"] == "free")
            self.hybrid.setState_(self.s["provider"] == "hybrid")
            self.claude.setState_(self.s["provider"] == "claude")

        @objc.python_method
        def _set(self, k, v):
            self.s[k] = v
            save_settings(self.s, state_dir)
            self.refresh_(None)

        def setGuide_(self, _): self._set("mode", "guide")
        def setAuto_(self, _): self._set("mode", "auto")
        def setFree_(self, _): self._set("provider", "free")
        def setHybrid_(self, _): self._set("provider", "hybrid")
        def setClaude_(self, _): self._set("provider", "claude")

        @objc.python_method
        def start_hotkey(self):
            """Right Option or F5 while off: start a voice run that records at once.
            F5 while working (not recording): stop, same as Escape. While recording the run itself counts presses."""
            def spawn():
                if agent_state(state_dir)[0] == "off" and time.time() - self.last_spawn > 3:
                    self.last_spawn = time.time()
                    subprocess.Popen(run_args(self.s, ["--voice", "--listening"]), start_new_session=True,
                                     stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

            def on_flags(event):
                if event.keyCode() == 61 and event.modifierFlags() & AppKit.NSEventModifierFlagOption:
                    spawn()

            def on_key(event):
                if event.keyCode() != 96 or event.isARepeat():
                    return
                if agent_state(state_dir)[0] == "off":
                    spawn()
                elif time.time() - self.last_spawn > 3 and not recording(state_dir):
                    trigger_stop(state_dir)
            self.last_spawn = 0.0
            self.monitor = AppKit.NSEvent.addGlobalMonitorForEventsMatchingMask_handler_(
                AppKit.NSEventMaskFlagsChanged, on_flags)
            self.key_monitor = AppKit.NSEvent.addGlobalMonitorForEventsMatchingMask_handler_(
                AppKit.NSEventMaskKeyDown, on_key)

        @objc.python_method
        def run_inbox(self):
            if agent_state(state_dir)[0] != "off" or time.time() - self.last_spawn < 3:
                return
            job = next_goal(state_dir)
            if job:
                self.last_spawn = time.time()
                out = inbox_dirs(state_dir)[1] / f"{job[0]}.txt"
                with open(out, "w") as fh:  # result file for the session that sent the goal
                    subprocess.Popen(["/bin/sh", "-c", '"$@"; echo; echo "[end]"', "sh",
                                      *run_args(self.s, ["--goal", job[1]])],
                                     start_new_session=True, stdout=fh, stderr=subprocess.STDOUT)

        def talkNow_(self, _):
            if agent_state(state_dir)[0] == "off":
                self.last_spawn = time.time()
                subprocess.Popen(run_args(self.s, ["--voice", "--listening"]), start_new_session=True,
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        def checkSetup_(self, _):
            from .runner import doctor
            code, lines = doctor()  # runs in this process, so it reports the menu bar's own permissions
            AppKit.NSApp().activateIgnoringOtherApps_(True)
            alert = AppKit.NSAlert.alloc().init()
            alert.setMessageText_("Ready" if code == 0 else "Setup needs attention")
            alert.setInformativeText_("\n".join(lines))
            alert.runModal()

        def openGuide_(self, _):
            subprocess.Popen(["open", str(GUIDE_PDF)])

        def newGoal_(self, _):
            if agent_state(state_dir)[0] == "off":
                subprocess.Popen(run_args(self.s), start_new_session=True,
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)

        def stopAgent_(self, _):
            trigger_stop(state_dir)

        def showHeld_(self, _):
            held = paths(state_dir)["stop"].parent / "held.jsonl"
            held.touch()
            subprocess.Popen(["open", "-e", str(held)])

        def quit_(self, _):
            AppKit.NSApp().terminate_(None)

    return Controller


def run_menubar(state_dir=None) -> None:  # pragma: no cover - needs the window server
    import AppKit
    Controller = controller_class(state_dir)
    app = AppKit.NSApplication.sharedApplication()
    app.setActivationPolicy_(AppKit.NSApplicationActivationPolicyAccessory)  # menu bar only, no Dock icon
    c = Controller.alloc().init()
    c.setup()
    app.run()


if __name__ == "__main__":  # pragma: no cover
    run_menubar()
