"""Guide mode: highlight the next target; down arrow plans the next step, up arrow goes back.

Nothing here can post an input event. The only output is `highlight(action)`.
"""
from __future__ import annotations

from typing import Callable

from .actions import Action, ActionError
from .kill_switch import stop_requested
from .next_action import Planner, Screen
from .safety import ScreenContext, check_action


class GuideSession:
    def __init__(self, goal: str, planner: Planner, observe: Callable[[], Screen],
                 context: Callable[[], ScreenContext], highlight: Callable[[Action | None], None],
                 max_steps: int = 25, state_dir=None):
        self.goal, self.planner, self.observe, self.context = goal, planner, observe, context
        self.highlight, self.max_steps, self.state_dir = highlight, max_steps, state_dir
        self.history: list[Action] = []
        self.index = -1
        self.status = "active"  # active, done, stopped, blocked, failed, needs_user

    def current(self) -> Action | None:
        return self.history[self.index] if 0 <= self.index < len(self.history) else None

    def down(self) -> Action | None:
        """Step forward. At the newest step, ask the planner for the next one from the current screen."""
        if self.status != "active":
            return self.current()
        if stop_requested(self.state_dir):
            self.status = "stopped"
            self.highlight(None)
            return None
        if self.index < len(self.history) - 1:
            self.index += 1
            self.highlight(self.current())
            return self.current()
        if len(self.history) >= self.max_steps:
            self.status = "stopped"
            return self.current()
        try:
            a = self.planner.next_action(self.goal, self.observe())
        except (ActionError, RuntimeError):
            self.status = "failed"
            return self.current()
        if a.kind in ("done", "ask_user"):
            self.status = "done" if a.kind == "done" else "needs_user"
            self.highlight(None)
            return a
        if not check_action(a, self.context(), "guide").allowed:
            self.status = "blocked"
            self.highlight(None)
            return a
        self.history.append(a)
        self.index = len(self.history) - 1
        self.highlight(a)
        return a

    def up(self) -> Action | None:
        if self.index > 0:
            self.index -= 1
        self.highlight(self.current())
        return self.current()


def highlight_to_file(state_dir=None) -> Callable[[Action | None], None]:
    from .glow import clear_highlight, write_highlight

    def show(a: Action | None) -> None:
        if a is None or a.kind != "click":
            clear_highlight(state_dir)  # type, key and scroll have no screen point; the label is spoken/printed
        else:
            write_highlight(a.x, a.y, a.target_label, state_dir)
    return show
