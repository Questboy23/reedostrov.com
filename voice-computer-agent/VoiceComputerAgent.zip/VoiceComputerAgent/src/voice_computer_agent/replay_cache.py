"""Replays successful action sequences with zero model calls.

Each stored step keeps a fingerprint of the screen it ran on. Before each replayed step the
current screen must match, or replay stops and the planner takes over. Typed text is never stored.
"""
from __future__ import annotations

import hashlib
import json
from dataclasses import asdict
from pathlib import Path

from .actions import Action


def fingerprint(app_name: str, ui_text: str) -> str:
    """Hash of app plus the stable AX labels. Coarse on purpose so clocks and counters do not break it."""
    labels = sorted({line.strip() for line in ui_text.splitlines() if line.strip() and not any(c.isdigit() for c in line)})
    return hashlib.sha256((app_name + "\n" + "\n".join(labels)).encode()).hexdigest()[:16]


def _goal_key(goal: str) -> str:
    return hashlib.sha256(" ".join(goal.lower().split()).encode()).hexdigest()[:16]


class ReplayCache:
    def __init__(self, path: Path):
        self.path = Path(path)
        self.data: dict = json.loads(self.path.read_text()) if self.path.exists() else {}

    def save(self, goal: str, steps: list[tuple[str, Action]]) -> bool:
        """steps: (fingerprint, action). Sequences with typing are refused, so no typed secret is stored."""
        if any(a.kind == "type" for _, a in steps):
            return False
        self.data[_goal_key(goal)] = [{"fp": fp, "action": asdict(a)} for fp, a in steps]
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self.data))
        return True

    def steps(self, goal: str) -> list[tuple[str, Action]]:
        return [(s["fp"], Action(**s["action"])) for s in self.data.get(_goal_key(goal), [])]

    def replay(self, goal: str, current_fp, act) -> int:
        """current_fp(): fingerprint now. act(action): performs it. Returns steps replayed."""
        done = 0
        for fp, action in self.steps(goal):
            if current_fp() != fp:
                break
            act(action)
            done += 1
        return done
