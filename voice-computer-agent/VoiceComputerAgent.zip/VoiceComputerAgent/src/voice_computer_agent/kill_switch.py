"""Watchdog process. Runs apart from the agent and owns the Escape listener.

On Escape: write the stop file, SIGKILL the agent's process group, clear the queue, kill the glow.
The agent checks `stop_requested()` immediately before posting every input event.
"""
from __future__ import annotations

import os
import signal
from pathlib import Path

STATE_DIR = Path(os.environ.get("VCA_STATE_DIR", Path.home() / ".voice-computer-agent"))
ESCAPE_KEYCODE = 53


def paths(state_dir: Path = None):
    d = Path(state_dir or STATE_DIR)
    return {"stop": d / "STOP", "queue": d / "queue.jsonl", "agent_pgid": d / "agent.pgid", "glow_pid": d / "glow.pid",
            "watchdog_ready": d / "watchdog.ready"}


def stop_requested(state_dir: Path = None) -> bool:
    return paths(state_dir)["stop"].exists()


def watchdog_alive(state_dir: Path = None) -> bool:
    """True only if watchdog.ready names a live process. Input posting stops when this is false."""
    try:
        pid = int(paths(state_dir)["watchdog_ready"].read_text().strip())
        if pid <= 1:
            return False
        os.kill(pid, 0)
        return True
    except (OSError, ValueError):
        return False


def _kill_from_file(f: Path, group: bool) -> None:
    try:
        pid = int(f.read_text().strip())
    except (OSError, ValueError):
        return
    if pid <= 1 or pid == os.getpid() or (group and pid == os.getpgid(0)):
        return  # never kill init or the watchdog itself
    try:
        (os.killpg if group else os.kill)(pid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        pass  # macOS killpg gives EPERM when only a zombie is left in the group
    f.unlink(missing_ok=True)


def trigger_stop(state_dir: Path = None) -> None:
    """Order matters: stop flag first so an in-flight event sees it, then kill."""
    p = paths(state_dir)
    p["stop"].parent.mkdir(parents=True, exist_ok=True)
    p["stop"].write_text("escape")
    _kill_from_file(p["agent_pgid"], group=True)
    _kill_from_file(p["glow_pid"], group=False)
    p["queue"].write_text("")


def run_watchdog() -> None:  # pragma: no cover - needs Accessibility grant
    import Quartz

    tap_ref = []

    def callback(proxy, etype, event, refcon):
        if etype in (Quartz.kCGEventTapDisabledByTimeout, Quartz.kCGEventTapDisabledByUserInput):
            if tap_ref:
                Quartz.CGEventTapEnable(tap_ref[0], True)  # macOS disables slow taps; turn it back on
            return event
        if etype == Quartz.kCGEventKeyDown and \
                Quartz.CGEventGetIntegerValueField(event, Quartz.kCGKeyboardEventKeycode) == ESCAPE_KEYCODE:
            trigger_stop()
        return event  # passed through unchanged

    tap = Quartz.CGEventTapCreate(Quartz.kCGSessionEventTap, Quartz.kCGHeadInsertEventTap,
                                  Quartz.kCGEventTapOptionDefault,  # active tap needs Accessibility only, not Input Monitoring
                                  Quartz.CGEventMaskBit(Quartz.kCGEventKeyDown), callback, None)
    if tap is None:
        raise SystemExit("Accessibility not granted to the watchdog; agent will not start.")
    tap_ref.append(tap)
    src = Quartz.CFMachPortCreateRunLoopSource(None, tap, 0)
    Quartz.CFRunLoopAddSource(Quartz.CFRunLoopGetCurrent(), src, Quartz.kCFRunLoopCommonModes)
    Quartz.CGEventTapEnable(tap, True)
    ready = paths()["watchdog_ready"]
    ready.parent.mkdir(parents=True, exist_ok=True)
    ready.write_text(str(os.getpid()))  # the runner refuses to start until this file names a live watchdog
    Quartz.CFRunLoopRun()


if __name__ == "__main__":  # pragma: no cover
    run_watchdog()
