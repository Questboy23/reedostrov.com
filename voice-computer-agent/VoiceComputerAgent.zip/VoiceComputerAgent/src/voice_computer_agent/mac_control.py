"""macOS screen, AX and input. Every CGEventPost goes through `_post`, which checks the stop file first.

Coordinates: actions carry normalized 0..1 values; `to_points()` maps them to the main
display's size in points, which is what CGEvent uses, so Retina scale never applies.
Frames stay in memory as JPEG bytes and are never written to disk.
"""
from __future__ import annotations

from collections import deque
from typing import Callable

from .actions import Action, to_points
from .kill_switch import stop_requested, watchdog_alive
from .safety import ScreenContext

KEYCODES = {"return": 36, "tab": 48, "space": 49, "delete": 51, "left": 123, "right": 124,
            "down": 125, "up": 126, "l": 37, "t": 17, "w": 13, "f": 3, "c": 8, "v": 9, "n": 45, "\\": 42}  # backslash: 1Password autofill (cmd+\\)
TEXT_INPUT_ROLES = {"AXTextField", "AXTextArea", "AXComboBox", "AXSearchField"}
UNKNOWN_ROLE = "AXUnknown"  # safety blocks typing when the focused role cannot be read


class Stopped(RuntimeError):
    """Raised when the stop file exists before an event would be posted."""


_Q = None  # Quartz module, or a fake in tests
_BG_PID = None  # background target app; None means act on the visible screen


def set_background_target(pid: int | None) -> None:
    """Background mode: events go to one app's process and clicks use AXPress, so the mouse never moves."""
    global _BG_PID
    _BG_PID = pid


def _q():
    global _Q
    if _Q is None:
        import Quartz
        _Q = Quartz
    return _Q


def _post(event, state_dir=None) -> None:
    if stop_requested(state_dir):
        raise Stopped("kill switch")
    if not watchdog_alive(state_dir):
        raise Stopped("watchdog not running")
    q = _q()
    if _BG_PID:
        q.CGEventPostToPid(_BG_PID, event)
    else:
        q.CGEventPost(q.kCGHIDEventTap, event)


def screen_points() -> tuple[float, float]:
    q = _q()
    b = q.CGDisplayBounds(q.CGMainDisplayID())
    return float(b.size.width), float(b.size.height)


def scaled_size(w: int, h: int, max_w: int) -> tuple[int, int]:
    if w <= max_w:
        return w, h
    return max_w, max(1, round(h * max_w / w))


def capture_frame(max_w: int = 640, quality: float = 0.6) -> bytes | None:
    """One downscaled JPEG of the main display, in memory. None without Screen Recording."""
    q = _q()
    if not q.CGPreflightScreenCaptureAccess():
        return None
    img = q.CGDisplayCreateImage(q.CGMainDisplayID())
    return None if img is None else encode_jpeg(img, max_w, quality)


def encode_jpeg(img, max_w: int = 1280, quality: float = 0.6) -> bytes | None:
    q = _q()
    w, h = scaled_size(q.CGImageGetWidth(img), q.CGImageGetHeight(img), max_w)
    cs = q.CGColorSpaceCreateDeviceRGB()
    ctx = q.CGBitmapContextCreate(None, w, h, 8, 0, cs, q.kCGImageAlphaPremultipliedLast)
    q.CGContextSetInterpolationQuality(ctx, q.kCGInterpolationMedium)
    q.CGContextDrawImage(ctx, q.CGRectMake(0, 0, w, h), img)
    small = q.CGBitmapContextCreateImage(ctx)
    data = q.CFDataCreateMutable(None, 0)
    dest = q.CGImageDestinationCreateWithData(data, "public.jpeg", 1, None)
    q.CGImageDestinationAddImage(dest, small, {q.kCGImageDestinationLossyCompressionQuality: quality})
    if not q.CGImageDestinationFinalize(dest):
        return None
    return bytes(data)


# ---- Accessibility -------------------------------------------------------------------

def _ax():
    import ApplicationServices as AS
    return AS


def _ax_get(el, attr):
    err, val = _ax().AXUIElementCopyAttributeValue(el, attr, None)
    return val if err == 0 else None


def summarize_tree(root, get: Callable, max_nodes: int = 80, max_depth: int = 8) -> str:
    """Breadth-first list of 'role: label' lines. Labels are cut to 60 chars. Pure, so tests use a fake `get`."""
    lines, queue, seen = [], deque([(root, 0)]), 0
    while queue and seen < max_nodes:
        el, depth = queue.popleft()
        seen += 1
        role = get(el, "AXRole") or "?"
        if get(el, "AXSubrole") == "AXSecureTextField" or role == "AXSecureTextField":
            continue  # never read or describe password fields
        label = get(el, "AXTitle") or get(el, "AXDescription") or ""
        if not label and role not in TEXT_INPUT_ROLES:
            label = get(el, "AXValue") or ""  # text field contents stay on the Mac
        if not isinstance(label, str):
            label = ""
        label = " ".join(label.split())[:60]
        if label or role in ("AXButton", "AXTextField", "AXLink", "AXMenuItem", "AXCheckBox"):
            lines.append(f"{'  ' * depth}{role}: {label}")
        if depth < max_depth:
            for child in get(el, "AXChildren") or []:
                queue.append((child, depth + 1))
    return "\n".join(lines)


def _has_onscreen_window(pid: int) -> bool:
    """A closed Spotlight panel can still report keyboard focus. Trust it only if it has a window on screen."""
    q = _q()
    wins = q.CGWindowListCopyWindowInfo(q.kCGWindowListOptionOnScreenOnly,
                                        q.kCGNullWindowID) or []
    return any(int(w.get("kCGWindowOwnerPID", -1)) == pid and float(w.get("kCGWindowAlpha", 1)) > 0 for w in wins)


def frontmost_app():
    AS = _ax()
    import AppKit
    app = None
    if _BG_PID:
        app = AppKit.NSRunningApplication.runningApplicationWithProcessIdentifier_(_BG_PID)
    else:
        # System-wide focus: Spotlight and other panels own the keyboard without being the frontmost app.
        focused = _ax_get(AS.AXUIElementCreateSystemWide(), "AXFocusedApplication")
        if focused is not None:
            err, pid = AS.AXUIElementGetPid(focused, None)
            if err == 0 and _has_onscreen_window(pid):
                app = AppKit.NSRunningApplication.runningApplicationWithProcessIdentifier_(pid)
        if app is None:  # NSWorkspace only refreshes frontmostApplication when the run loop turns; spin it once
            AppKit.NSRunLoop.currentRunLoop().runUntilDate_(AppKit.NSDate.dateWithTimeIntervalSinceNow_(0.02))
            app = AppKit.NSWorkspace.sharedWorkspace().frontmostApplication()
    if app is None:
        return None, ""
    return AS.AXUIElementCreateApplication(app.processIdentifier()), str(app.localizedName() or "")


def ax_summary(max_nodes: int = 80) -> str:
    el, _ = frontmost_app()
    if el is None:
        return ""
    win = _ax_get(el, "AXFocusedWindow") or el
    return summarize_tree(win, _ax_get, max_nodes=max_nodes)


def context_from(app_name: str, window_title: str, role, subrole, label) -> ScreenContext:
    """Secure fields report role AXTextField and subrole AXSecureTextField; the gate needs the subrole."""
    if subrole == "AXSecureTextField":
        role = "AXSecureTextField"
    return ScreenContext(app_name=app_name, window_title=window_title or "",
                         focused_role=role or UNKNOWN_ROLE, focused_label=label or "")


def focused_context() -> ScreenContext:
    el, name = frontmost_app()
    if el is None:
        return ScreenContext(focused_role=UNKNOWN_ROLE)
    win = _ax_get(el, "AXFocusedWindow")
    title = _ax_get(win, "AXTitle") if win is not None else ""
    focus = _ax_get(el, "AXFocusedUIElement")
    if focus is None:
        return context_from(name, title, None, None, "")
    label = " ".join(str(v) for a in ("AXTitle", "AXDescription", "AXPlaceholderValue", "AXHelp", "AXIdentifier")
                     if (v := _ax_get(focus, a)))
    return context_from(name, title, _ax_get(focus, "AXRole"), _ax_get(focus, "AXSubrole"), label)


# ---- Input ---------------------------------------------------------------------------

def click(x: float, y: float, state_dir=None) -> None:
    if _BG_PID:
        return _ax_press_at(x, y, state_dir)
    q = _q()
    pt = q.CGPointMake(*to_points(x, y, *screen_points()))
    for etype in (q.kCGEventMouseMoved, q.kCGEventLeftMouseDown, q.kCGEventLeftMouseUp):
        _post(q.CGEventCreateMouseEvent(None, etype, pt, q.kCGMouseButtonLeft), state_dir)


def _ax_press_at(x: float, y: float, state_dir=None) -> None:
    if stop_requested(state_dir):
        raise Stopped("kill switch")
    if not watchdog_alive(state_dir):
        raise Stopped("watchdog not running")
    AS = _ax()
    px, py = to_points(x, y, *screen_points())
    err, el = AS.AXUIElementCopyElementAtPosition(AS.AXUIElementCreateApplication(_BG_PID), px, py, None)
    if err != 0 or el is None:
        raise RuntimeError("no element at that point in the background app")
    AS.AXUIElementPerformAction(el, "AXPress")


def type_text(text: str, state_dir=None) -> None:
    q = _q()
    for ch in text:
        for down in (True, False):
            ev = q.CGEventCreateKeyboardEvent(None, 0, down)
            q.CGEventKeyboardSetUnicodeString(ev, len(ch.encode("utf-16-le")) // 2, ch)
            _post(ev, state_dir)


def press_key(combo: str, state_dir=None) -> None:
    q = _q()
    parts = combo.split("+")
    flags = q.kCGEventFlagMaskCommand if "cmd" in parts[:-1] else 0
    code = KEYCODES[parts[-1]]
    for down in (True, False):
        ev = q.CGEventCreateKeyboardEvent(None, code, down)
        q.CGEventSetFlags(ev, flags)
        _post(ev, state_dir)


def scroll(dy: int, state_dir=None) -> None:
    q = _q()
    _post(q.CGEventCreateScrollWheelEvent(None, q.kCGScrollEventUnitLine, 1, dy), state_dir)


def bring_front(name_lower: str) -> None:
    """Force an app to the front through Accessibility (AXFrontmost), which macOS honours from background processes."""
    import AppKit
    from ApplicationServices import AXUIElementCreateApplication, AXUIElementSetAttributeValue
    for app in AppKit.NSWorkspace.sharedWorkspace().runningApplications():
        if (app.localizedName() or "").lower() == name_lower:
            app.unhide()
            AXUIElementSetAttributeValue(AXUIElementCreateApplication(app.processIdentifier()), "AXFrontmost", True)
            return


def open_app(name: str, state_dir=None) -> None:
    """`open -a` first: instant and reliable (Spotlight left the old app in front on macOS 26).
    Falls back to Spotlight (cmd+space, type, return) when no app has that exact name."""
    import subprocess
    import time
    from .kill_switch import stop_requested
    if stop_requested(state_dir):
        raise Stopped()
    if subprocess.run(["/usr/bin/open", "-a", name], capture_output=True, timeout=10).returncode == 0:
        want = name.lower().removesuffix(".app")
        for i in range(30):  # wait up to 3 s for it to come to the front
            if focused_context().app_name.lower() == want:
                return
            if i in (5, 15):
                bring_front(want)  # macOS 26 may refuse `open` activation from a background process
            time.sleep(0.1)
        return
    press_key("cmd+space", state_dir)
    for _ in range(20):
        time.sleep(0.1)
        if focused_context().app_name == "Spotlight":
            break
    else:
        raise RuntimeError("Spotlight did not take focus; nothing typed")
    type_text(name, state_dir)
    time.sleep(0.6)
    press_key("return", state_dir)
    time.sleep(1.0)


def execute(action: Action, state_dir=None) -> None:
    """Auto-mode executor. Only click, type, key and scroll post events."""
    if action.kind == "click":
        click(action.x, action.y, state_dir)
    elif action.kind == "type":
        type_text(action.text, state_dir)
    elif action.kind == "key":
        press_key(action.key, state_dir)
    elif action.kind == "scroll":
        scroll(action.dy, state_dir)
    elif action.kind == "open_app":
        open_app(action.name, state_dir)
    elif action.kind == "click_ref":
        from .kill_switch import stop_requested
        from .ui_refs import press
        if stop_requested(state_dir):
            raise Stopped()
        press(action.ref)
    else:
        raise ValueError(f"not an input action: {action.kind}")
