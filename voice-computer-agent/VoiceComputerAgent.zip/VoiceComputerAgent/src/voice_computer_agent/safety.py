"""Gates checked before every action. Decisions here never come from the model."""
from __future__ import annotations

import re
from dataclasses import dataclass

from .actions import Action

DENY_APPS_AUTO = {
    "1password", "bitwarden", "lastpass", "dashlane", "keychain access",
    "system settings", "system preferences", "passwords",
}
BANK_WORDS = re.compile(r"\b(bank|chase|wells fargo|schwab|fidelity|vanguard|paypal|venmo|coinbase|robinhood)\b", re.I)
MONEY_WORDS = re.compile(
    r"\b(buy|purchase|pay|payment|checkout|check out|place order|order now|subscribe|subscription|upgrade|"
    r"donate|tip|transfer|send money|wire|bid|add card|add payment|apple pay|confirm purchase|book now|rent)\b",
    re.I)
CONFIRM_WORDS = re.compile(
    r"\b(send|post|reply|submit|buy|purchase|order|checkout|pay|place order|delete|remove|trash|erase|"
    r"settings|preferences|uninstall|transfer)\b", re.I)
PAYMENT_FIELD = re.compile(r"\b(card|cvv|cvc|expir|iban|routing|account number|password|passcode|pin|ssn)\b", re.I)
TERMINAL_APPS = {"terminal", "iterm2", "iterm", "warp", "ghostty", "alacritty", "kitty", "wezterm"}
SELF_APP_NAMES = {"voice computer agent", "voice-computer-agent"}


@dataclass
class ScreenContext:
    app_name: str = ""
    window_title: str = ""
    url: str = ""
    focused_role: str = ""   # AX role of the focused element
    focused_label: str = ""  # AX title/description of the focused element


@dataclass
class Verdict:
    allowed: bool
    needs_confirm: bool = False
    reason: str = ""


def check_action(action: Action, ctx: ScreenContext, mode: str) -> Verdict:
    """mode is 'auto' or 'guide'. Guide mode never acts, so only labels matter there."""
    app = ctx.app_name.lower().strip()
    if app in SELF_APP_NAMES:
        return Verdict(False, reason="agent may not act on its own windows")
    if mode == "auto":
        if app in DENY_APPS_AUTO:
            return Verdict(False, reason=f"deny list: {app}")
        if BANK_WORDS.search(f"{ctx.window_title} {ctx.url}"):
            return Verdict(False, reason="deny list: banking")
        if app in TERMINAL_APPS and not (action.kind == "key" and action.key == "cmd+space") \
                and action.kind != "open_app":  # open_app types only after Spotlight has focus
            return Verdict(False, reason="never types or clicks in a terminal; only cmd+space to leave it")
    if action.kind == "open_app":
        target = action.name.lower().removesuffix(".app")
        if target in SELF_APP_NAMES or target in TERMINAL_APPS or \
                (mode == "auto" and (target in DENY_APPS_AUTO or BANK_WORDS.search(target))):
            return Verdict(False, reason=f"deny list: {target}")
        return Verdict(True)
    if action.kind == "type" or (action.kind == "key" and action.key == "cmd+v"):
        if ctx.focused_role in ("AXSecureTextField", "AXUnknown") or PAYMENT_FIELD.search(ctx.focused_label):
            return Verdict(False, reason="never type into password or payment fields")
    if action.kind in ("click", "click_ref", "key"):
        if mode == "auto" and MONEY_WORDS.search(action.target_label):
            return Verdict(False, reason="hard limit: no spending money")
        if CONFIRM_WORDS.search(action.target_label):
            return Verdict(True, needs_confirm=True, reason=f"confirm: {action.target_label[:40]}")
        if action.kind == "key" and action.key == "return" and CONFIRM_WORDS.search(ctx.focused_label):
            return Verdict(True, needs_confirm=True, reason="confirm: return on a send/submit control")
    return Verdict(True)


@dataclass
class TaskLimits:
    max_steps: int = 25
    max_seconds: float = 180.0
    max_tokens: int = 60_000
    max_repeats: int = 3


class TaskBudget:
    def __init__(self, limits: TaskLimits, clock):
        self.limits, self.clock = limits, clock
        self.start = clock()
        self.steps = self.tokens = 0
        self.history: list[Action] = []

    def record(self, action: Action, tokens: int) -> None:
        self.steps += 1
        self.tokens += tokens
        self.history.append(action)

    def extend(self) -> None:
        """Start a fresh step, time and token window (Claude keeps going until the goal is done)."""
        self.start, self.steps, self.tokens, self.history = self.clock(), 0, 0, []

    def stop_reason(self) -> str | None:
        L = self.limits
        if self.steps >= L.max_steps:
            return "step limit"
        if self.clock() - self.start >= L.max_seconds:
            return "time limit"
        if self.tokens >= L.max_tokens:
            return "token limit"
        tail = self.history[-L.max_repeats:]
        if len(tail) == L.max_repeats and len(set(tail)) == 1 and tail[0].kind != "scroll":
            return "same action repeated"
        return None
