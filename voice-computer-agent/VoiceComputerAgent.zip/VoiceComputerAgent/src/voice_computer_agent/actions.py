"""Strict parser for one model action. Model output is untrusted text."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass, field

ACTION_FIELDS = {
    "click": {"x", "y"},
    "click_ref": {"ref"},  # press a UI element by its id from the UI list (agent-desktop); no mouse move
    "type": {"text"},
    "key": {"key"},
    "scroll": {"dy"},
    "open_app": {"name"},
    "done": set(),
    "ask_user": {"question"},
}
OPTIONAL_FIELDS = {"reason", "target_label"}
FORBIDDEN_KEYS = {"escape", "esc"}  # the agent may never send the kill key
ALLOWED_KEYS = {"return", "tab", "space", "delete", "up", "down", "left", "right",
                "cmd+l", "cmd+t", "cmd+w", "cmd+f", "cmd+c", "cmd+v", "cmd+n", "cmd+space"}
MAX_TEXT = 500


class ActionError(ValueError):
    pass


@dataclass(frozen=True)
class Action:
    kind: str
    x: float | None = None  # normalized 0..1 across the screen width
    y: float | None = None
    text: str | None = None
    key: str | None = None
    dy: int | None = None
    question: str | None = None
    name: str | None = None
    ref: str | None = None
    target_label: str = ""
    reason: str = field(default="", compare=False)

    def log_view(self) -> dict:
        """What may be written to logs: no typed text."""
        view = {"kind": self.kind, "target_label": self.target_label[:40]}
        if self.text is not None:
            view["text_len"] = len(self.text)
        if self.key:
            view["key"] = self.key
        if self.name:
            view["app"] = self.name[:40]
        return view


def parse_action(raw: str) -> Action:
    """Parse exactly one JSON object. Anything else raises ActionError."""
    raw = raw.strip()
    if raw.startswith("```"):
        raw = raw.strip("`").removeprefix("json").strip()
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        raise ActionError(f"not json: {e.msg}") from None
    if not isinstance(data, dict):
        raise ActionError("not an object")
    kind = data.get("action")
    if kind not in ACTION_FIELDS:
        raise ActionError(f"unknown action {kind!r}")
    keys = set(data) - {"action"}
    required = ACTION_FIELDS[kind]
    if missing := required - keys:
        raise ActionError(f"missing {sorted(missing)}")
    if extra := keys - required - OPTIONAL_FIELDS:
        raise ActionError(f"unexpected {sorted(extra)}")
    a = {k: data[k] for k in keys}
    if kind == "click":
        for c in ("x", "y"):
            v = a[c]
            if isinstance(v, bool) or not isinstance(v, (int, float)) or not 0 <= v <= 1:
                raise ActionError(f"{c} must be a number in 0..1")
            a[c] = float(v)
    if kind == "click_ref":
        if not isinstance(a["ref"], str) or not re.fullmatch(r"e\d{1,5}", a["ref"].strip()):
            raise ActionError("ref must look like e12")
        a["ref"] = a["ref"].strip()
    if kind == "type":
        if not isinstance(a["text"], str) or not a["text"] or len(a["text"]) > MAX_TEXT:
            raise ActionError("text must be 1..500 chars")
        if any(ord(c) < 0x20 or ord(c) == 0x7f for c in a["text"]):
            raise ActionError("text may not contain control characters (newline, tab, escape)")
    if kind == "open_app":
        nm = a["name"]
        if not isinstance(nm, str) or not nm.strip() or len(nm) > 60 or any(ord(c) < 0x20 or ord(c) == 0x7f for c in nm):
            raise ActionError("name must be 1..60 printable chars")
        a["name"] = nm.strip()
    if kind == "key":
        k = a["key"]
        if not isinstance(k, str):
            raise ActionError("key must be a string")
        k = k.lower().strip()
        if k in FORBIDDEN_KEYS or "escape" in k:
            raise ActionError("escape is reserved for the kill switch")
        if k not in ALLOWED_KEYS:
            raise ActionError(f"key {k!r} not allowed")
        a["key"] = k
    if kind == "scroll" and (isinstance(a["dy"], bool) or not isinstance(a["dy"], int) or abs(a["dy"]) > 50):
        raise ActionError("dy must be an int in -50..50")
    for s in ("reason", "target_label", "question"):
        if s in a and not isinstance(a[s], str):
            raise ActionError(f"{s} must be a string")
    return Action(kind=kind, **a)


def to_points(x: float, y: float, width_pt: float, height_pt: float) -> tuple[float, float]:
    """Normalized coords to macOS points. CGEvent uses points, so Retina scale never applies."""
    return round(x * width_pt, 1), round(y * height_pt, 1)
