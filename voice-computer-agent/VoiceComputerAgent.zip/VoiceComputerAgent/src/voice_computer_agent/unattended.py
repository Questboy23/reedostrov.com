"""Unattended mode: the user grants full control for a set time ("I'm going to sleep, here are your limits").

The grant is written only by `vca grant`, which the user runs and confirms by typing GRANT.
It holds the time, token and step limits, the goals, and which held categories are allowed.
Hard limits apply to every grant and cannot be switched off by any setting:
  - no spending money: purchase, payment, checkout, subscribe, donate, transfer, bid, add card
  - no typing into password or payment fields
  - no deny-list apps (password managers, Keychain Access, System Settings, banking)
  - no Escape key, no acting on the agent's own windows or files
Actions that would normally need a yes (send, delete, settings) are held for the morning
unless the grant allows that category. Held actions are logged without typed text.
"""
from __future__ import annotations

import json
import os
import re
import time
from dataclasses import asdict, dataclass, field
from pathlib import Path

from .actions import Action
from .kill_switch import paths
from .safety import CONFIRM_WORDS, MONEY_WORDS, ScreenContext, Verdict, check_action

MONEY_PAGES = re.compile(r"\b(checkout|cart|billing|payment|subscribe|pricing|wallet|order)\b", re.I)
ALLOWABLE = {"send", "delete"}  # categories a grant may allow; money and settings are never allowable
MAX_HOURS = 12.0
MAX_TOKENS = 2_000_000


class GrantError(ValueError):
    pass


@dataclass
class Grant:
    goals: list[str]
    hours: float = 8.0
    max_tokens: int = 200_000
    max_steps_per_goal: int = 60
    background: bool = False
    app: str = ""  # background mode acts inside this one app; the visible screen and mouse are left alone
    allow: list[str] = field(default_factory=list)
    created_at: float = 0.0

    def validate(self) -> "Grant":
        if not self.goals or not all(isinstance(g, str) and g.strip() for g in self.goals):
            raise GrantError("at least one goal")
        if not 0 < self.hours <= MAX_HOURS:
            raise GrantError(f"hours must be in (0, {MAX_HOURS}]")
        if not 0 < self.max_tokens <= MAX_TOKENS:
            raise GrantError(f"max_tokens must be in (0, {MAX_TOKENS}]")
        if not 0 < self.max_steps_per_goal <= 500:
            raise GrantError("max_steps_per_goal must be in (0, 500]")
        if self.background and not self.app.strip():
            raise GrantError("background mode needs --app: the one app it works in")
        if bad := set(self.allow) - ALLOWABLE:
            raise GrantError(f"cannot allow {sorted(bad)}: money and settings are hard limits")
        return self

    def expires_at(self) -> float:
        return self.created_at + self.hours * 3600

    def expired(self, now: float) -> bool:
        return now >= self.expires_at()


def grant_path(state_dir=None) -> Path:
    return paths(state_dir)["stop"].parent / "grant.json"


def write_grant(grant: Grant, state_dir=None, ask=input, out=print, now=time.time) -> bool:
    """Only the user runs this (vca grant). Requires typing GRANT."""
    grant.created_at = now()
    grant.validate()
    out(f"Full control for {grant.hours} h, {grant.max_tokens} tokens, {len(grant.goals)} goal(s), "
        f"background={'on' if grant.background else 'off'}, also allowed: {grant.allow or 'nothing extra'}.")
    out("Never allowed: spending money, password or payment fields, System Settings, Keychain, banking.")
    out("Escape stops everything at once. Type GRANT to start.")
    if ask("> ").strip() != "GRANT":
        out("Not granted.")
        return False
    p = grant_path(state_dir)
    p.parent.mkdir(parents=True, exist_ok=True)
    fd = os.open(p, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump(asdict(grant), f)
    return True


def load_grant(state_dir=None, now=time.time) -> Grant | None:
    p = grant_path(state_dir)
    if not p.exists():
        return None
    try:
        g = Grant(**json.loads(p.read_text())).validate()
    except (TypeError, ValueError, GrantError):
        return None  # a damaged grant is no grant
    return None if g.expired(now()) else g


def revoke_grant(state_dir=None) -> None:
    grant_path(state_dir).unlink(missing_ok=True)


def category(action: Action, ctx: ScreenContext) -> str | None:
    text = f"{action.target_label} {ctx.focused_label}"
    if action.kind in ("click", "click_ref", "key") and (MONEY_WORDS.search(text) or
                                             (MONEY_PAGES.search(f"{ctx.window_title} {ctx.url}")
                                              and CONFIRM_WORDS.search(text))):
        return "money"
    if re.search(r"\b(delete|remove|trash|erase|uninstall)\b", text, re.I):
        return "delete"
    if re.search(r"\b(send|post|reply|submit)\b", text, re.I):
        return "send"
    if re.search(r"\b(settings|preferences)\b", text, re.I):
        return "settings"
    return None


def check_unattended(action: Action, ctx: ScreenContext, grant: Grant) -> Verdict:
    """Hard limits first, then the normal auto-mode gates, then held categories."""
    if category(action, ctx) == "money":
        return Verdict(False, reason="hard limit: no spending money")
    base = check_action(action, ctx, "auto")
    if not base.allowed:
        return base
    if base.needs_confirm:
        cat = category(action, ctx)
        if cat in grant.allow:
            return Verdict(True, reason=f"allowed by grant: {cat}")
        return Verdict(True, needs_confirm=True, reason=f"held for review: {cat or 'confirm'}")
    return base


def hold(action: Action, reason: str, goal: str, state_dir=None, now=time.time) -> None:
    """Record a held action for the morning. log_view() carries no typed text."""
    p = paths(state_dir)["stop"].parent / "held.jsonl"
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "a") as f:
        f.write(json.dumps({"t": int(now()), "goal": goal[:120], "reason": reason, "action": action.log_view()}) + "\n")


def run_grant(grant: Grant, make_planner, observe, context, act, state_dir=None,
              clock=time.time, set_glow=None, run_task_fn=None, front_app=None) -> list[dict]:
    """Works through the grant's goals one by one. Stops at once on Escape, revoke, expiry or the token cap.

    make_planner() -> Planner (fresh per goal). Tokens are summed across goals against grant.max_tokens.
    Returns one result row per goal attempted; rows hold status and reason, never typed text.
    """
    from .kill_switch import stop_requested
    from .safety import TaskBudget, TaskLimits
    from .task_loop import run_task
    run_task_fn = run_task_fn or run_task
    used, rows = 0, []
    for goal in grant.goals:
        if stop_requested(state_dir):
            rows.append({"goal": goal[:120], "status": "stopped", "reason": "kill switch"}); break
        if load_grant(state_dir, now=clock) is None:
            rows.append({"goal": goal[:120], "status": "stopped", "reason": "grant revoked or expired"}); break
        left_tokens = grant.max_tokens - used
        left_seconds = grant.expires_at() - clock()
        if left_tokens <= 0 or left_seconds <= 0:
            rows.append({"goal": goal[:120], "status": "stopped", "reason": "grant limits reached"}); break
        if set_glow:
            set_glow("background" if grant.background else "foreground", goal)
        planner = make_planner()
        budget = TaskBudget(TaskLimits(grant.max_steps_per_goal, left_seconds, left_tokens), clock)
        res = run_task_fn(goal, planner, observe, context, act, budget, "auto", state_dir,
                          gate=lambda a, c: check_unattended(a, c, grant), front_app=front_app)
        used += planner.tokens_used
        if res.status == "needs_confirm" and res.action is not None:
            hold(res.action, res.reason, goal, state_dir, now=clock)
            res.status = "held"
        rows.append({"goal": goal[:120], "status": res.status, "reason": res.reason, "steps": res.steps,
                     "tokens": planner.tokens_used})
        if res.status == "stopped" and res.reason == "kill switch":
            break
    return rows
