"""UI element ids from agent-desktop (vercel-labs/agent-desktop, pinned 1.2.0).

snapshot() turns its JSON tree into short 'e12 button: Save' lines for the model. press() clicks an
element through the accessibility press action, so the mouse never moves and it works in background.
"""
from __future__ import annotations

import json
import shutil
import subprocess

BIN = shutil.which("agent-desktop") or "/opt/homebrew/bin/agent-desktop"
MAX_LINES = 150


def flatten(snap: dict) -> tuple[str, str, dict[str, str]]:
    """(snapshot_id, text lines, {'e12': 'button: Save'}). Pure, so tests feed it JSON."""
    data = snap.get("data") or {}
    sid, lines, labels = data.get("snapshot_id", ""), [], {}

    def walk(node, depth):
        ref = node.get("ref_id", "")
        name = (node.get("name") or node.get("description") or node.get("value") or "").replace("\n", " ")[:60]
        if ref and len(lines) < MAX_LINES:
            short = ref.rsplit(":", 1)[-1]
            label = f"{node.get('role', '?')}: {name}"
            labels[short] = label
            lines.append(f"{'  ' * min(depth, 6)}{short} {label}")
        for c in node.get("children") or []:
            walk(c, depth + 1)
    walk(data.get("tree") or {}, 0)
    return sid, "\n".join(lines), labels


def snapshot(run=subprocess.run) -> tuple[str, str, dict[str, str]] | None:
    """Focused window's interactive elements, or None when agent-desktop is missing or fails."""
    try:
        r = run([BIN, "snapshot", "--surface", "focused", "-i", "--compact"], capture_output=True, text=True,
                timeout=15)
        snap = json.loads(r.stdout)
    except (OSError, ValueError, subprocess.TimeoutExpired):
        return None
    return flatten(snap) if snap.get("ok") else None


def press(qualified_ref: str, run=subprocess.run) -> None:
    r = run([BIN, "click", qualified_ref], capture_output=True, text=True, timeout=15)
    try:
        ok = json.loads(r.stdout).get("ok")
    except ValueError:
        ok = False
    if not ok:
        raise RuntimeError(f"agent-desktop click failed: {(r.stdout or r.stderr)[-200:]}")
