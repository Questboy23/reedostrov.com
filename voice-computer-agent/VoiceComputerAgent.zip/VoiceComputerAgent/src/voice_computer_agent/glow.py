"""Glow overlay: its own process, one click-through borderless window over the main screen.

It draws a soft edge glow while the agent runs, plus a ring around the guide-mode target
read from highlight.json (normalized x, y, label). Its PID goes in glow.pid so the
watchdog can SIGKILL it on Escape. It also exits on its own when the STOP file appears.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from .kill_switch import STATE_DIR, paths


def highlight_path(state_dir: Path = None) -> Path:
    return Path(state_dir or STATE_DIR) / "highlight.json"


def write_highlight(x: float, y: float, label: str, state_dir: Path = None) -> None:
    p = highlight_path(state_dir)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps({"x": x, "y": y}))  # coords only: screen-derived labels stay in memory
    tmp.replace(p)  # atomic, so the overlay never reads half a file


def clear_highlight(state_dir: Path = None) -> None:
    highlight_path(state_dir).unlink(missing_ok=True)


def read_highlight(state_dir: Path = None) -> dict | None:
    try:
        d = json.loads(highlight_path(state_dir).read_text())
        x, y = float(d["x"]), float(d["y"])
    except (OSError, ValueError, KeyError, TypeError):
        return None
    if not (0 <= x <= 1 and 0 <= y <= 1):
        return None
    return {"x": x, "y": y}


GREEN = (0.30, 0.85, 0.45)
YELLOW = (1.0, 0.78, 0.0)  # Claude in the cloud is planning
EDGE_ALPHAS = (0.14, 0.08, 0.045, 0.02)  # very slight: outer ring 14% opacity, fading inward


def glow_state_path(state_dir: Path = None) -> Path:
    return paths(state_dir)["stop"].parent / "glow_state.json"


def write_glow_state(state: str, label: str = "", state_dir: Path = None, cloud: bool = False, goal: str = "") -> None:
    """state: 'foreground' (acting on the visible screen) or 'background' (acting in one app, mouse untouched).
    cloud: Claude is planning (yellow). goal: the user's own goal text, shown in the corner."""
    if state not in ("foreground", "background"):
        raise ValueError(state)
    p = glow_state_path(state_dir)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps({"state": state, "label": label[:60], "cloud": bool(cloud), "goal": goal[:80]}))
    tmp.replace(p)  # atomic: the overlay and menu bar never read half a file


def read_glow_state(state_dir: Path = None) -> dict:
    try:
        d = json.loads(glow_state_path(state_dir).read_text())
        if d.get("state") in ("foreground", "background"):
            return d
    except (OSError, ValueError):
        pass
    return {"state": "foreground", "label": "", "cloud": False, "goal": ""}


def edge_alpha(state: str, t: float) -> float:
    """Foreground glow flashes (1 s cycle). Background glow breathes slowly (4 s cycle): 'working elsewhere'."""
    import math
    if state == "background":
        return 0.55 + 0.45 * (0.5 + 0.5 * math.sin(t * math.pi / 2))
    return 0.35 + 0.65 * (0.5 + 0.5 * math.cos(t * 2 * math.pi))


def run_overlay(state_dir: Path = None) -> None:  # pragma: no cover - needs a window server
    import AppKit
    from Foundation import NSObject, NSTimer

    p = paths(state_dir)
    p["glow_pid"].parent.mkdir(parents=True, exist_ok=True)
    p["glow_pid"].write_text(str(os.getpid()))

    class GlowView(AppKit.NSView):
        def isFlipped(self):
            return True  # top-left origin, same as the normalized action coords

        def drawRect_(self, rect):
            import time as _t
            b = self.bounds()
            st = read_glow_state(state_dir)
            k = edge_alpha(st["state"], _t.monotonic())
            edge = YELLOW if st.get("cloud") or st["state"] == "background" else GREEN
            for i, alpha in enumerate(EDGE_ALPHAS):
                AppKit.NSColor.colorWithCalibratedRed_green_blue_alpha_(*edge, alpha * k).set()
                path = AppKit.NSBezierPath.bezierPathWithRect_(AppKit.NSInsetRect(b, 2 + i * 5, 2 + i * 5))
                path.setLineWidth_(5)
                path.stroke()
            if st["state"] == "background":
                text = AppKit.NSString.stringWithString_(f"Working in background: {st['label']}".strip(": "))
                attrs = {AppKit.NSFontAttributeName: AppKit.NSFont.systemFontOfSize_(12),
                         AppKit.NSForegroundColorAttributeName: AppKit.NSColor.whiteColor()}
                size = text.sizeWithAttributes_(attrs)
                w, h = size.width + 24, 24
                rect = (((b.size.width - w) / 2, 34), (w, h))
                AppKit.NSColor.colorWithCalibratedRed_green_blue_alpha_(0.10, 0.45, 0.22, 0.85).set()
                AppKit.NSBezierPath.bezierPathWithRoundedRect_xRadius_yRadius_(rect, 12, 12).fill()
                text.drawAtPoint_withAttributes_((rect[0][0] + 12, rect[0][1] + 4), attrs)
            if st.get("goal"):  # top-right corner: the goal and who is planning it
                who = "Claude (cloud)" if st.get("cloud") else "On this Mac"
                text = AppKit.NSString.stringWithString_(f"Goal: {st['goal']}  ·  {who}  ·  Esc stops")
                attrs = {AppKit.NSFontAttributeName: AppKit.NSFont.systemFontOfSize_(12),
                         AppKit.NSForegroundColorAttributeName: AppKit.NSColor.blackColor()}
                size = text.sizeWithAttributes_(attrs)
                w, h = size.width + 20, 22
                rect = ((b.size.width - w - 30, 34), (w, h))
                AppKit.NSColor.colorWithCalibratedRed_green_blue_alpha_(*edge, 0.9).set()
                AppKit.NSBezierPath.bezierPathWithRoundedRect_xRadius_yRadius_(rect, 11, 11).fill()
                text.drawAtPoint_withAttributes_((rect[0][0] + 10, rect[0][1] + 3), attrs)
            h = read_highlight(state_dir)
            if h:
                cx, cy = h["x"] * b.size.width, h["y"] * b.size.height
                AppKit.NSColor.colorWithCalibratedRed_green_blue_alpha_(1.0, 0.75, 0.1, 0.9).set()
                ring = AppKit.NSBezierPath.bezierPathWithOvalInRect_(((cx - 28, cy - 28), (56, 56)))
                ring.setLineWidth_(4)
                ring.stroke()

    class Ticker(NSObject):
        def tick_(self, timer):
            if p["stop"].exists():
                p["glow_pid"].unlink(missing_ok=True)
                os._exit(0)
            view.setNeedsDisplay_(True)

    app = AppKit.NSApplication.sharedApplication()
    app.setActivationPolicy_(AppKit.NSApplicationActivationPolicyAccessory)  # no Dock icon, never takes focus
    frame = AppKit.NSScreen.mainScreen().frame()
    win = AppKit.NSWindow.alloc().initWithContentRect_styleMask_backing_defer_(
        frame, AppKit.NSWindowStyleMaskBorderless, AppKit.NSBackingStoreBuffered, False)
    win.setOpaque_(False)
    win.setBackgroundColor_(AppKit.NSColor.clearColor())
    win.setIgnoresMouseEvents_(True)  # click-through
    win.setLevel_(AppKit.NSStatusWindowLevel)
    win.setCollectionBehavior_(AppKit.NSWindowCollectionBehaviorCanJoinAllSpaces
                               | AppKit.NSWindowCollectionBehaviorStationary
                               | AppKit.NSWindowCollectionBehaviorIgnoresCycle)
    win.setTitle_("voice-computer-agent glow")
    view = GlowView.alloc().initWithFrame_(((0, 0), (frame.size.width, frame.size.height)))
    win.setContentView_(view)
    win.orderFrontRegardless()
    ticker = Ticker.alloc().init()
    NSTimer.scheduledTimerWithTimeInterval_target_selector_userInfo_repeats_(0.1, ticker, b"tick:", None, True)
    app.run()


def start_overlay(state_dir: Path = None):
    """Spawn the overlay as its own process and session, so killing the agent group leaves it to the watchdog."""
    import subprocess
    import sys
    env = {**os.environ}
    if state_dir:
        env["VCA_STATE_DIR"] = str(state_dir)
    return subprocess.Popen([sys.executable, "-m", "voice_computer_agent.glow"], env=env, start_new_session=True,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


if __name__ == "__main__":  # pragma: no cover
    run_overlay()
