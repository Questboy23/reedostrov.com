"""Command line entry: `vca run`, `vca doctor`.

Start order for a task: clear STOP, start the watchdog and wait for its ready file, write
agent.pgid, check Claude consent, get the goal, start the glow, run. If the watchdog is
not live, the agent refuses to start.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
import time
from pathlib import Path

from .kill_switch import STATE_DIR, paths, stop_requested

CONSENT_TEXT = (
    "Claude mode sends, for every step, one downscaled screenshot of your main display and a text "
    "summary of the frontmost window's accessibility tree to Anthropic through your own "
    "Claude Code sign-in (claude -p, Haiku), so it counts against your Claude plan's usage limit and never "
    "bills a paid API key. Hybrid mode (the default) does this only for the steps where the free model "
    "is stuck. Free mode sends nothing off this Mac."
)
CONSENT_VERSION = hashlib.sha256(CONSENT_TEXT.encode()).hexdigest()[:16]


class RefuseStart(SystemExit):
    pass


def prepare_state_dir(state_dir: Path = None) -> Path:
    """0700 state dir; remove leftovers a SIGKILL can strand (audio, highlight, stale pgid)."""
    d = Path(state_dir or STATE_DIR)
    d.mkdir(parents=True, exist_ok=True)
    os.chmod(d, 0o700)
    for name in ("ptt.wav", "highlight.json", "highlight.tmp", "agent.pgid"):
        (d / name).unlink(missing_ok=True)
    return d


# ---- watchdog ------------------------------------------------------------------------

def start_watchdog(state_dir: Path = None, cmd: list[str] | None = None, timeout: float = 10.0):
    """Spawn the watchdog in its own session and wait for it to report a live event tap."""
    p = paths(state_dir)
    p["watchdog_ready"].parent.mkdir(parents=True, exist_ok=True)
    p["watchdog_ready"].unlink(missing_ok=True)
    env = {**os.environ, "VCA_STATE_DIR": str(p["stop"].parent)}
    proc = subprocess.Popen(cmd or [sys.executable, "-m", "voice_computer_agent.kill_switch"], env=env,
                            start_new_session=True, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    deadline = time.time() + timeout
    while time.time() < deadline:
        if proc.poll() is not None:
            err = (proc.stderr.read() or b"").decode(errors="replace").strip().splitlines()
            raise RefuseStart(f"watchdog exited ({err[-1] if err else proc.returncode}); agent refuses to start")
        try:
            if int(p["watchdog_ready"].read_text().strip()) == proc.pid:
                return proc
        except (OSError, ValueError):
            pass
        time.sleep(0.05)
    proc.kill()
    raise RefuseStart("watchdog not ready in time; agent refuses to start")


# ---- consent -------------------------------------------------------------------------

def consent_path(state_dir: Path = None) -> Path:
    return Path(state_dir or STATE_DIR) / "claude_consent.json"


def has_consent(state_dir: Path = None) -> bool:
    try:
        return json.loads(consent_path(state_dir).read_text()).get("version") == CONSENT_VERSION
    except (OSError, ValueError, AttributeError):
        return False


def ask_consent(state_dir: Path = None, ask=input, out=print) -> bool:
    """First run of Claude mode. Only the literal word 'yes' grants consent. Text changes re-ask."""
    if has_consent(state_dir):
        return True
    out(CONSENT_TEXT)
    if ask("Type yes to allow Claude mode: ").strip().lower() != "yes":
        return False
    p = consent_path(state_dir)
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps({"version": CONSENT_VERSION, "at": time.strftime("%Y-%m-%dT%H:%M:%S%z")}))
    return True


def consent_dialog(prompt: str, run=subprocess.run) -> str:
    """Consent for runs started from the menu bar, which have no terminal to type in."""
    text = (CONSENT_TEXT + "\n\n" + prompt).replace("\\", "").replace('"', "'")
    r = run(["osascript", "-e", f'text returned of (display dialog "{text}" default answer "" '
             'with title "voice-computer-agent" buttons {"Cancel", "OK"} default button "OK")'],
            capture_output=True, text=True, timeout=600)
    return r.stdout.strip() if r.returncode == 0 else ""


def password_handoff(run=subprocess.run) -> bool:
    """The agent never types passwords. The user fills the field (1Password: Cmd+Backslash), then the task resumes."""
    msg = ("A password is needed. Fill it yourself with 1Password (Cmd+Backslash) or by typing, "
           "then click Continue. The agent never sees or types passwords.")
    r = run(["osascript", "-e", f'button returned of (display dialog "{msg}" with title "voice-computer-agent" '
             'buttons {"Stop", "Continue"} default button "Continue")'], capture_output=True, text=True, timeout=600)
    return r.returncode == 0 and r.stdout.strip() == "Continue"


def ask_task_permission(goal: str, run=subprocess.run) -> bool:
    """One yes per task before it touches the computer. Unanswered in 120 s counts as no."""
    g = goal.replace("\\", "").replace('"', "'")[:200]
    msg = (f"Let the agent use your computer for: {g}\n\nIt may click, type, send and delete as needed and "
           "tells you each send or delete. Never: passwords, payments, banking, System Settings. Escape stops it.")
    r = run(["osascript", "-e", f'button returned of (display dialog "{msg}" with title "voice-computer-agent" '
             'buttons {"Deny", "Allow"} default button "Allow" giving up after 120)'],
            capture_output=True, text=True, timeout=130)
    return r.returncode == 0 and r.stdout.strip() == "Allow"


def notify(text: str, run=subprocess.run) -> None:
    """macOS notification (top right, Notification Center). Text is the user's goal or the agent's own step."""
    t = text.replace("\\", "").replace('"', "'")[:200]
    run(["osascript", "-e", f'display notification "{t}" with title "Voice Computer Agent"'],
        capture_output=True, timeout=10)


# ---- goal ----------------------------------------------------------------------------

def goal_from_box(run=subprocess.run) -> str:
    """Typed goal box: a native macOS dialog through osascript. The goal never comes from the screen."""
    script = ('text returned of (display dialog "What should the agent do?" default answer "" '
              'with title "voice-computer-agent" buttons {"Cancel", "Go"} default button "Go")')
    r = run(["osascript", "-e", script], capture_output=True, text=True, timeout=600)
    if r.returncode != 0:
        return ""
    return r.stdout.strip()[:500]


# ---- doctor --------------------------------------------------------------------------

def doctor(probe=None) -> tuple[int, list[str]]:
    """Returns (exit code, lines). Exit 1 when a grant the agent needs is missing."""
    probe = probe or _real_probe
    checks = probe()
    lines, missing = [], 0
    for name, ok, needed, fix in checks:
        lines.append(f"{'OK  ' if ok else 'MISS'} {name}" + ("" if ok else f"  -> {fix}"))
        missing += (not ok) and needed
    lines.append("All required grants present." if not missing else f"{missing} required item(s) missing.")
    return (1 if missing else 0), lines


def _real_probe():
    from . import voice
    try:
        import ApplicationServices as AS
        import Quartz
        ax, scr = bool(AS.AXIsProcessTrusted()), bool(Quartz.CGPreflightScreenCaptureAccess())
    except ImportError:
        ax = scr = False
    who = f"the app that runs this command ({os.environ.get('TERM_PROGRAM', 'your terminal')})"
    try:
        import urllib.request
        urllib.request.urlopen("http://127.0.0.1:11434/api/tags", timeout=2).close()
        ollama = True
    except OSError:
        ollama = False
    from .next_action import CLAUDE_BIN
    key = CLAUDE_BIN.exists()
    return [
        ("Accessibility", ax, True, f"System Settings > Privacy & Security > Accessibility: turn on {who}"),
        ("Screen Recording", scr, True, f"System Settings > Privacy & Security > Screen & System Audio Recording: turn on {who}"),
        ("whisper.cpp + model", voice.WHISPER_BIN.exists() and voice.WHISPER_MODEL.exists(), False,
         "run scripts/install_whisper.sh (needed for push-to-talk only)"),
        ("ollama on 127.0.0.1:11434", ollama, False, "start ollama (needed for free mode)"),
        ("Claude Code for Claude mode (uses your subscription)", key, False,
         "install Claude Code and sign in with `claude` (Claude mode only; never uses a paid API key)"),
    ]


# ---- run -----------------------------------------------------------------------------

def build_parser() -> argparse.ArgumentParser:
    ap = argparse.ArgumentParser(prog="vca")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("doctor", help="report missing grants")
    sub.add_parser("menubar", help="show the menu bar control (next to Wi-Fi)")
    sd = sub.add_parser("send", help="queue a goal for the menu bar to run (for other Claude sessions)")
    sd.add_argument("goal")
    sd.add_argument("--wait", type=float, default=0, help="seconds to wait for the result (0 = return at once)")
    g = sub.add_parser("grant", help="give full control for a set time (you type GRANT)")
    g.add_argument("--goal", action="append", required=True, help="repeat for several goals")
    g.add_argument("--hours", type=float, default=8.0)
    g.add_argument("--max-tokens", type=int, default=200_000)
    g.add_argument("--max-steps", type=int, default=60)
    g.add_argument("--app", default="", help="background mode: the one app to work in")
    g.add_argument("--allow", action="append", default=[], choices=["send", "delete"])
    o = sub.add_parser("overnight", help="run the current grant now")
    o.add_argument("--provider", choices=["free", "claude"], default="free")
    sub.add_parser("revoke", help="cancel the grant")
    sub.add_parser("held", help="show actions held for your review")
    r = sub.add_parser("run", help="run one goal")
    src = r.add_mutually_exclusive_group(required=True)
    src.add_argument("--goal", help="typed goal")
    src.add_argument("--box", action="store_true", help="ask for the goal in a dialog box")
    src.add_argument("--voice", action="store_true", help="push-to-talk: press Right Option to start, again to send")
    r.add_argument("--mode", choices=["auto", "guide"], default="guide")
    r.add_argument("--provider", choices=["free", "hybrid", "claude"], default="hybrid",
                   help="free: offline only. hybrid (default): free first, Claude when stuck. claude: Claude every step")
    r.add_argument("--max-steps", type=int, default=25)
    r.add_argument("--max-seconds", type=float, default=180.0)
    r.add_argument("--max-tokens", type=int, default=60_000)
    r.add_argument("--no-glow", action="store_true")
    r.add_argument("--listening", action="store_true", help=argparse.SUPPRESS)  # menu bar hotkey already pressed
    r.add_argument("--escalate", action="store_true", help=argparse.SUPPRESS)  # old name for --provider hybrid
    r.add_argument("--no-replay", action="store_true", help="do not replay or save action sequences")
    r.add_argument("--stop-at-limits", action="store_true",
                   help="stop at the step, time and token limits even when Claude is driving")
    return ap


def exit_cleanly_on_sigterm() -> None:
    """SIGTERM skips finally blocks, which left the glow and watchdog running; turn it into SystemExit."""
    import signal
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(143))


def run(args, state_dir: Path = None) -> int:  # pragma: no cover - drives the real Mac
    import dataclasses
    from . import glow, guide, mac_control, ui_refs  # noqa: F401
    from .actions import ActionError
    from .next_action import ClaudeProvider, LocalOllama, Planner, Screen, Settings
    from .safety import TaskBudget, TaskLimits
    from .task_loop import run_task

    code, lines = doctor()
    if code:
        print("\n".join(lines))
        return 2
    try:
        os.setsid()  # own process group, so Escape's killpg can never reach the parent shell
    except PermissionError:
        pass  # already a session leader
    exit_cleanly_on_sigterm()
    p = paths(state_dir)
    prepare_state_dir(state_dir)
    p["stop"].unlink(missing_ok=True)  # a new task from the user clears the last Escape
    watchdog = start_watchdog(state_dir)
    p["agent_pgid"].write_text(str(os.getpgid(0)))
    overlay = None
    try:
        from .next_action import CLAUDE_BIN
        provider = "hybrid" if args.escalate and args.provider == "free" else args.provider
        consent = has_consent(state_dir)
        if provider != "free" and not consent:
            consent = ask_consent(state_dir) if sys.stdin.isatty() else \
                ask_consent(state_dir, ask=consent_dialog, out=lambda _: None)
        if provider == "claude" and not consent:
            print("No consent: Claude mode not started.")
            return 3
        if provider == "hybrid" and not (consent and CLAUDE_BIN.exists()):
            print("Claude not connected (no consent or no Claude Code): running free, offline.")
            provider = "free"
        if args.goal:
            goal = args.goal
        elif args.box:
            goal = goal_from_box()
        else:
            from .voice import push_to_talk_goal
            goal = push_to_talk_goal(state_dir, already_pressed=args.listening)
        if not goal.strip():
            print("No goal.")
            return 4
        if args.mode == "auto" and not ask_task_permission(goal):
            print("Not allowed: you said no.")
            return 5
        notify(f"Started: {goal}")
        use_claude = provider != "free"
        # Free sends nothing off the Mac. Hybrid asks Claude only when the free model is stuck.
        settings = Settings(mode="claude" if provider == "claude" else "free",
                            escalate_to_claude=provider == "hybrid", claude_consent=use_claude)
        planner = Planner(settings, LocalOllama(), ClaudeProvider() if use_claude else None)

        refs: dict = {}

        def observe():
            snap = ui_refs.snapshot()
            refs.clear()
            if snap:
                refs.update(sid=snap[0], labels=snap[2])
            return Screen(png=mac_control.capture_frame() or b"", ui_text=snap[1] if snap else mac_control.ax_summary())

        def resolve(action):
            if action.kind != "click_ref":
                return action
            label = refs.get("labels", {}).get(action.ref)
            if label is None:
                raise ActionError(f"unknown element {action.ref}")
            return dataclasses.replace(action, ref=f"@{refs['sid']}:{action.ref}", target_label=label)
        def show_state(action=None):
            glow.write_glow_state("foreground", "", state_dir, cloud=planner.on_claude, goal=goal)
            return action

        def resolve_and_show(action):
            show_state()  # yellow from the step Claude takes over
            return resolve(action)

        show_state()
        if not args.no_glow:
            overlay = glow.start_overlay(state_dir)
        if args.mode == "guide":
            return _guide_loop(guide.GuideSession(goal, planner, observe, mac_control.focused_context,
                                                  guide.highlight_to_file(state_dir), args.max_steps, state_dir))
        budget = TaskBudget(TaskLimits(args.max_steps, args.max_seconds, args.max_tokens), time.monotonic)
        try:
            from .replay_cache import ReplayCache, fingerprint
            for _ in range(3):  # up to 3 password handoffs per task
                res = run_task(goal, planner, observe, mac_control.focused_context,
                               lambda a: mac_control.execute(a, state_dir), budget, "auto", state_dir,
                               until_done=not args.stop_at_limits, preapproved=True, notify=notify,
                               front_app=lambda: mac_control.focused_context().app_name,
                               replay=None if args.no_replay else ReplayCache(p["stop"].parent / "replay_cache.json"),
                               fp=lambda: fingerprint(mac_control.focused_context().app_name, mac_control.ax_summary()),
                               resolve=resolve_and_show)
                if not (res.status == "blocked" and "password" in res.reason and password_handoff()):
                    break
        except mac_control.Stopped:
            print("stopped: kill switch")
            return 0
        print(f"{res.status}: {res.reason} ({res.steps} steps, {planner.tokens_used} tokens)")
        notify(f"{res.status}: {res.reason}"[:200])
        return 0 if res.status == "done" else 1
    finally:
        if overlay and overlay.poll() is None:
            overlay.kill()
        p["glow_pid"].unlink(missing_ok=True)
        watchdog.kill()
        p["agent_pgid"].unlink(missing_ok=True)


def run_overnight(args, state_dir: Path = None) -> int:  # pragma: no cover - drives the real Mac
    """Runs the user's grant. Same start order as run(): doctor, own session, watchdog, then glow."""
    from . import glow, mac_control
    from . import unattended as U
    from .next_action import ClaudeProvider, LocalOllama, Planner, Screen, Settings

    grant = U.load_grant(state_dir)
    if grant is None:
        print("No valid grant. Run: vca grant --goal \"...\" --hours 8")
        return 2
    code, lines = doctor()
    if code:
        print("\n".join(lines))
        return 2
    try:
        os.setsid()
    except PermissionError:
        pass
    exit_cleanly_on_sigterm()
    p = paths(state_dir)
    prepare_state_dir(state_dir)
    p["stop"].unlink(missing_ok=True)
    watchdog = start_watchdog(state_dir)
    p["agent_pgid"].write_text(str(os.getpgid(0)))
    overlay = None
    try:
        consent = has_consent(state_dir)
        if args.provider == "claude" and not consent:
            print("Claude mode needs consent first: run `vca run --provider claude --goal test` once while awake.")
            return 3
        if grant.background:
            import AppKit
            apps = [a for a in AppKit.NSWorkspace.sharedWorkspace().runningApplications()
                    if str(a.localizedName() or "").lower() == grant.app.lower()]
            if not apps:
                print(f"Background app not running: {grant.app}")
                return 4
            mac_control.set_background_target(apps[0].processIdentifier())
        overlay = glow.start_overlay(state_dir)
        use_claude = args.provider == "claude"

        def make_planner():
            return Planner(Settings(mode=args.provider, escalate_to_claude=False, claude_consent=use_claude),
                           LocalOllama(), ClaudeProvider() if use_claude else None)

        def observe():
            return Screen(png=mac_control.capture_frame() or b"", ui_text=mac_control.ax_summary())
        try:
            rows = U.run_grant(grant, make_planner, observe, mac_control.focused_context,
                               lambda a: mac_control.execute(a, state_dir), state_dir, time.time,
                               lambda st, label: glow.write_glow_state(st, label, state_dir))
        except mac_control.Stopped:
            print("stopped: kill switch")
            return 0
        for r in rows:
            print(f"{r['status']}: {r['goal']} ({r.get('steps', 0)} steps, {r.get('tokens', 0)} tokens) {r['reason']}")
        return 0
    finally:
        if overlay and overlay.poll() is None:
            overlay.kill()
        p["glow_pid"].unlink(missing_ok=True)
        watchdog.kill()
        p["agent_pgid"].unlink(missing_ok=True)


def _guide_loop(session) -> int:  # pragma: no cover - needs a listen-only key tap
    """Down arrow: next step. Up arrow: previous step. Escape is the watchdog's. Keys pass through."""
    import Quartz
    UP, DOWN = 126, 125

    def cb(proxy, etype, event, refcon):
        code = Quartz.CGEventGetIntegerValueField(event, Quartz.kCGKeyboardEventKeycode)
        if code == DOWN:
            a = session.down()
        elif code == UP:
            a = session.up()
        else:
            return event
        print(f"[{session.index + 1}/{len(session.history)}] {session.status}: "
              f"{a.kind if a else '-'} {a.target_label if a else ''}")
        return event

    tap = Quartz.CGEventTapCreate(Quartz.kCGSessionEventTap, Quartz.kCGHeadInsertEventTap,
                                  Quartz.kCGEventTapOptionListenOnly,
                                  Quartz.CGEventMaskBit(Quartz.kCGEventKeyDown), cb, None)
    if tap is None:
        print("guide keys need Input Monitoring")
        return 2
    Quartz.CFRunLoopAddSource(Quartz.CFRunLoopGetCurrent(), Quartz.CFMachPortCreateRunLoopSource(None, tap, 0),
                              Quartz.kCFRunLoopCommonModes)
    Quartz.CGEventTapEnable(tap, True)
    session.down()
    print("Guide mode: Down = next, Up = back, Escape = stop.")
    while session.status == "active" and not stop_requested(session.state_dir):
        Quartz.CFRunLoopRunInMode(Quartz.kCFRunLoopDefaultMode, 0.1, False)
    print(f"guide ended: {session.status}")
    return 0


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    if args.cmd == "send":
        from .menubar import send_goal, wait_result
        job = send_goal(args.goal)
        print(f"queued {job}")
        if args.wait:
            print(wait_result(job, args.wait) or "no result yet")
        return 0
    if args.cmd == "menubar":
        from .menubar import run_menubar
        run_menubar()
        return 0
    if args.cmd == "doctor":
        code, lines = doctor()
        print("\n".join(lines))
        return code
    if args.cmd in ("grant", "revoke", "held", "overnight"):
        from . import unattended as U
        if args.cmd == "grant":
            try:
                ok = U.write_grant(U.Grant(goals=args.goal, hours=args.hours, max_tokens=args.max_tokens,
                                           max_steps_per_goal=args.max_steps, background=bool(args.app),
                                           app=args.app, allow=args.allow))
            except U.GrantError as e:
                print(f"grant refused: {e}")
                return 2
            return 0 if ok else 1
        if args.cmd == "revoke":
            U.revoke_grant()
            print("grant revoked")
            return 0
        if args.cmd == "held":
            p = U.grant_path().parent / "held.jsonl"
            print(p.read_text() if p.exists() else "nothing held")
            return 0
        try:
            return run_overnight(args)
        except RefuseStart as e:
            print(e.code)
            return 5
    try:
        return run(args)
    except RefuseStart as e:
        print(e.code)
        return 5


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
