"""run_task: one goal, one action at a time, with every stop check in front of each step.

Screen capture, input and app context are injected, so the loop runs under test
without macOS grants. Guide mode passes a highlight function as `act`; auto mode passes
the input executor.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from .actions import Action, ActionError
from .kill_switch import stop_requested
from .next_action import Planner, Screen
from .safety import ScreenContext, TaskBudget, Verdict, check_action


@dataclass
class TaskResult:
    status: str   # "done", "stopped", "blocked", "needs_confirm", "needs_user", "failed"
    reason: str = ""
    steps: int = 0
    action: Action | None = None  # the blocked or held action, for the held log


def describe_steps(actions) -> str:
    out = []
    for i, a in enumerate(actions, 1):
        if a.kind == "click":
            out.append(f"{i}. click at ({a.x:.2f},{a.y:.2f}) {a.target_label}".rstrip())
        elif a.kind == "click_ref":
            out.append(f"{i}. pressed {a.target_label}")
        elif a.kind == "type":
            out.append(f"{i}. typed {a.text!r}")
        elif a.kind == "key":
            out.append(f"{i}. pressed {a.key}")
        else:
            out.append(f"{i}. {a.kind}")
    return "\n".join(out)


MAX_EXTENSIONS = 4  # Claude gets 5 limit windows in all (default 125 steps, 15 min, 300K tokens), then stops


def only_opens(goal: str, app: str) -> bool:
    """True when the goal is just 'open <app>', so reaching the app finishes it. 'open a new tab in Chrome' is not."""
    import re
    words = set(re.findall(r"[a-z0-9]+", goal.lower())) - {"open", "launch", "start", "the", "app", "application",
                                                             "please", "up", "okay", "ok", "can", "you", "my"}
    return words <= set(re.findall(r"[a-z0-9]+", app.lower()))


def run_task(
    goal: str,
    planner: Planner,
    observe: Callable[[], Screen],
    context: Callable[[], ScreenContext],
    act: Callable[[Action], None],
    budget: TaskBudget,
    mode: str = "auto",
    state_dir=None,
    gate: Callable[[Action, ScreenContext], "Verdict"] | None = None,
    front_app: Callable[[], str] | None = None,
    replay=None,
    fp: Callable[[], str] | None = None,
    resolve: Callable[[Action], Action] | None = None,
    until_done: bool = False,
    preapproved: bool = False,
    notify: Callable[[str], None] = lambda _: None,
) -> TaskResult:
    """gate replaces check_action (unattended mode passes check_unattended bound to its grant)."""
    if mode not in ("auto", "guide"):
        raise ValueError(f"mode must be 'auto' or 'guide', got {mode!r}")
    extensions = 0
    recorded: list = []  # (fingerprint before the step, action) for the replay cache

    def check(action):
        return gate(action, context()) if gate else check_action(action, context(), mode)

    def finish(reason: str) -> TaskResult:
        if replay is not None and recorded:
            replay.save(goal, recorded)  # refuses sequences with typing, so no typed text is stored
        return TaskResult("done", reason, budget.steps)

    if replay is not None and fp is not None:
        saved = replay.steps(goal)
        for want, action in saved:
            if stop_requested(state_dir):
                return TaskResult("stopped", "kill switch", budget.steps)
            verdict = check(action)  # replayed steps pass the same gate as planned ones
            if fp() != want or not verdict.allowed or verdict.needs_confirm:
                break
            act(action)
            recorded.append((want, action))
        else:
            if saved:
                return TaskResult("done", f"replayed {len(saved)} saved steps, no model calls", len(saved))
    while True:
        if stop_requested(state_dir):
            return TaskResult("stopped", "kill switch", budget.steps)
        reason = budget.stop_reason()
        if reason and reason != "same action repeated" and until_done and extensions < MAX_EXTENSIONS \
                and (planner.on_claude or planner.escalate()):
            extensions += 1
            budget.extend()  # Claude keeps going, up to 5x the base limits; a repeat loop still stops it
        elif reason:
            return TaskResult("stopped", reason, budget.steps)
        tokens_before = planner.tokens_used
        try:
            screen = observe()
            if screen is not None and front_app:
                screen.front_app = front_app()
            if screen is not None and budget.history:
                screen.history = describe_steps(budget.history[-6:])
            action = planner.next_action(goal, screen)
            if resolve:  # click_ref: swap the model's label for the element's real one before the gate
                action = resolve(action)
        except (ActionError, RuntimeError) as exc:
            if planner.escalate():  # hybrid: the free model is stuck, Claude takes over
                continue
            return TaskResult("failed", str(exc), budget.steps)
        budget.record(action, planner.tokens_used - tokens_before)
        if action.kind == "done":
            return finish(action.reason)
        if action.kind == "ask_user":
            return TaskResult("needs_user", action.question or "", budget.steps)
        verdict = check(action)
        if not verdict.allowed:
            if planner.escalate():  # hybrid: a blocked free-model action gets one Claude retry, same gate
                continue
            return TaskResult("blocked", verdict.reason, budget.steps, action)
        if verdict.needs_confirm:
            if not preapproved:
                return TaskResult("needs_confirm", verdict.reason, budget.steps, action)
            notify(f"Doing: {describe_steps([action])} ({verdict.reason})")  # approved at start; still tells the user
        # Race guard: the kill switch may fire between the check above and the act.
        if stop_requested(state_dir):
            return TaskResult("stopped", "kill switch", budget.steps)
        before = fp() if replay is not None and fp is not None else ""
        act(action)
        if before:
            recorded.append((before, action))
        # Small models keep clicking after the app opens; end deterministically once the target app is front.
        if action.kind == "open_app" and only_opens(goal, action.name) and front_app \
                and front_app().strip().lower() == action.name.strip().lower():
            return finish(f"{action.name} is in front")
