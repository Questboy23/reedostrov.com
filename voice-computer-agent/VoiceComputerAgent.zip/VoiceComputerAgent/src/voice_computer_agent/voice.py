"""Push-to-talk: press Right Option once to start, press again to stop. whisper.cpp transcribes on this Mac.

Audio goes to one 0600 temp WAV in the state dir and is deleted right after transcription.
"""
from __future__ import annotations

import os
import subprocess
import time
from pathlib import Path
from typing import Callable

from .kill_switch import STATE_DIR, stop_requested

WHISPER_DIR = Path(os.environ.get("VCA_WHISPER_DIR", Path.home() / ".voice-computer-agent" / "whisper"))
WHISPER_BIN = WHISPER_DIR / "bin" / "whisper-cli"
WHISPER_MODEL = WHISPER_DIR / "ggml-base.en.bin"
PTT_KEYCODE = 61  # Right Option
F5_KEYCODE = 96  # F5 (fn+F5 on keyboards where F5 is the dictation key)
MAX_RECORD_S = 30


def clean_transcript(raw: str) -> str:
    """Drop whisper's bracketed non-speech tags such as [BLANK_AUDIO] and join lines."""
    words = []
    for line in raw.splitlines():
        line = line.strip()
        if not line or (line.startswith("[") and line.endswith("]")) or (line.startswith("(") and line.endswith(")")):
            continue
        words.append(line)
    return " ".join(" ".join(words).split())[:500]


def verify_whisper_binary() -> None:
    """The installer records the built binary's sha256; a swapped binary is refused."""
    import hashlib
    want_f = WHISPER_BIN.with_name("whisper-cli.sha256")
    if not want_f.exists():
        raise RuntimeError("no recorded whisper-cli hash: rerun scripts/install_whisper.sh")
    got = hashlib.sha256(WHISPER_BIN.read_bytes()).hexdigest()
    if got != want_f.read_text().split()[0]:
        raise RuntimeError("whisper-cli hash mismatch: binary changed since install")


def transcribe(wav: Path, run=subprocess.run) -> str:
    if not WHISPER_BIN.exists() or not WHISPER_MODEL.exists():
        raise RuntimeError("whisper.cpp missing: run scripts/install_whisper.sh")
    verify_whisper_binary()
    r = run([str(WHISPER_BIN), "-m", str(WHISPER_MODEL), "-f", str(wav), "-nt", "-np", "-l", "en"],
            capture_output=True, text=True, timeout=120)
    if r.returncode != 0:
        raise RuntimeError(f"whisper-cli failed ({r.returncode})")
    return clean_transcript(r.stdout)


def record_while(held: Callable[[], bool], out: Path, max_s: float = MAX_RECORD_S) -> Path:  # pragma: no cover
    """Record 16 kHz mono 16-bit WAV while held() is true. Needs the Microphone grant."""
    import AVFoundation
    from Foundation import NSURL, NSDate, NSRunLoop
    settings = {AVFoundation.AVFormatIDKey: 1819304813,  # kAudioFormatLinearPCM 'lpcm'
                AVFoundation.AVSampleRateKey: 16000.0, AVFoundation.AVNumberOfChannelsKey: 1,
                AVFoundation.AVLinearPCMBitDepthKey: 16, AVFoundation.AVLinearPCMIsFloatKey: False}
    out.parent.mkdir(parents=True, exist_ok=True)
    out.touch(mode=0o600)
    rec, err = AVFoundation.AVAudioRecorder.alloc().initWithURL_settings_error_(
        NSURL.fileURLWithPath_(str(out)), settings, None)
    if rec is None or not rec.record():
        raise RuntimeError(f"microphone unavailable: {err}")
    start = time.time()
    while held() and time.time() - start < max_s and not stop_requested():
        NSRunLoop.currentRunLoop().runUntilDate_(NSDate.dateWithTimeIntervalSinceNow_(0.05))
    rec.stop()
    os.chmod(out, 0o600)  # the recorder may recreate the file with default permissions
    return out


def count_press(state: dict, down: bool) -> None:
    """Count key-down edges only, so holding the key counts as one press."""
    if down and not state["down"]:
        state["presses"] += 1
    state["down"] = down


def push_to_talk_goal(state_dir: Path | None = None, already_pressed: bool = False) -> str:  # pragma: no cover - needs Accessibility + Microphone
    """Block until Right Option is pressed, record until it is pressed again, return the transcript."""
    import Quartz
    state = {"down": False, "presses": 1 if already_pressed else 0}  # menu bar hotkey counts as the first press

    def cb(proxy, etype, event, refcon):
        code = Quartz.CGEventGetIntegerValueField(event, Quartz.kCGKeyboardEventKeycode)
        if code == PTT_KEYCODE and etype == Quartz.kCGEventFlagsChanged:
            count_press(state, bool(Quartz.CGEventGetFlags(event) & Quartz.kCGEventFlagMaskAlternate))
        elif code == F5_KEYCODE and etype in (Quartz.kCGEventKeyDown, Quartz.kCGEventKeyUp):
            count_press(state, etype == Quartz.kCGEventKeyDown)
        return event

    tap = Quartz.CGEventTapCreate(Quartz.kCGSessionEventTap, Quartz.kCGHeadInsertEventTap,
                                  Quartz.kCGEventTapOptionListenOnly,
                                  Quartz.CGEventMaskBit(Quartz.kCGEventFlagsChanged)
                                  | Quartz.CGEventMaskBit(Quartz.kCGEventKeyDown)
                                  | Quartz.CGEventMaskBit(Quartz.kCGEventKeyUp), cb, None)
    if tap is None:
        raise RuntimeError("push-to-talk needs Accessibility/Input Monitoring; use --box or --goal")
    src = Quartz.CFMachPortCreateRunLoopSource(None, tap, 0)
    loop = Quartz.CFRunLoopGetCurrent()
    Quartz.CFRunLoopAddSource(loop, src, Quartz.kCFRunLoopCommonModes)
    Quartz.CGEventTapEnable(tap, True)
    print("Press Right Option or F5 to start talking. Press it again to send.")
    if already_pressed:
        subprocess.Popen(["afplay", "/System/Library/Sounds/Tink.aiff"])  # recording has started: speak now
    while state["presses"] < 1:
        Quartz.CFRunLoopRunInMode(Quartz.kCFRunLoopDefaultMode, 0.05, False)
    wav = Path(state_dir or STATE_DIR) / "ptt.wav"
    wav.unlink(missing_ok=True)
    try:
        def held():
            Quartz.CFRunLoopRunInMode(Quartz.kCFRunLoopDefaultMode, 0.01, False)
            return state["presses"] < 2
        record_while(held, wav)
        return transcribe(wav)
    finally:
        wav.unlink(missing_ok=True)
        Quartz.CGEventTapEnable(tap, False)
